"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModel = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class UserModel {
    constructor() {
        this.tableName = 'Users';
        const client = new client_dynamodb_1.DynamoDBClient({});
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
    }
    async createUser(userData) {
        const params = {
            TableName: this.tableName,
            Item: userData
        };
        try {
            await this.docClient.send(new lib_dynamodb_1.PutCommand(params));
            return { success: true, message: 'Usuario creado exitosamente' };
        }
        catch (error) {
            console.error('Error al crear usuario:', error);
            throw error;
        }
    }
}
exports.UserModel = UserModel;
