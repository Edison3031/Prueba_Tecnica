"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const userModel_1 = require("../models/userModel");
class UserController {
    constructor() {
        this.userModel = new userModel_1.UserModel();
        const client = new client_dynamodb_1.DynamoDBClient({});
        this.ddbDocClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
    }
    async addUser(event) {
        try {
            if (!event.body) {
                throw new Error('No se proporcionó el cuerpo de la solicitud');
            }
            const book = event.body;
            const newBook = {
                ID: book.ID,
                Titulo: book.Titulo,
                Descripcion: book.Descripcion,
                Monto: book.Monto,
                Estado: book.Estado,
                Aprovacion1: book.Aprovacion1,
                Aprovacion2: book.Aprovacion2,
                Aprovacion3: book.Aprovacion3
            };
            await this.ddbDocClient.send(new lib_dynamodb_1.PutCommand({
                TableName: "Solicitudes",
                Item: newBook,
            }));
            return {
                statusCode: 201,
                body: JSON.stringify(newBook),
            };
        }
        catch (error) {
            console.error(error);
            return {
                statusCode: 500,
                body: JSON.stringify({ message: error instanceof Error ? error.message : 'Error interno del servidor' }),
            };
        }
    }
}
exports.UserController = UserController;
